import "bootstrap/dist/css/bootstrap.css";
import "./toru.css";
import "bootstrap/dist/js/bootstrap.bundle.js";

((root = document) => {
  const STORAGE_KEY = "toru-theme";
  const el = document.documentElement;

  const withThemeTransition = (fn) => {
    el.classList.add("theme-is-transitioning");
    try {
      fn();
    } finally {
      window.requestAnimationFrame(() => {
        window.setTimeout(() => {
          el.classList.remove("theme-is-transitioning");
        }, 260);
      });
    }
  };

  const getPreferred = () =>
    window.matchMedia &&
    window.matchMedia("(prefers-color-scheme: dark)").matches
      ? "dark"
      : "light";

  const normalizeSetting = (v) =>
    v === "auto" || v === "light" || v === "dark" ? v : "auto";

  const getSetting = () => normalizeSetting(localStorage.getItem(STORAGE_KEY));
  const setSetting = (v) =>
    localStorage.setItem(STORAGE_KEY, normalizeSetting(v));

  const getEffective = (setting) =>
    setting === "auto" ? getPreferred() : setting;

  const setThemeIcon = (setting, effective) => {
    const icon = root.getElementById("themeIcon");
    if (!icon) return;

    icon.className =
      "ego-i " +
      (setting === "dark"
        ? "i-moon"
        : setting === "light"
          ? "i-sun"
          : effective === "dark"
            ? "i-cloud-moon"
            : "i-cloud-sun");
  };

  const applyTheme = () => {
    const setting = getSetting();
    const effective = getEffective(setting);

    withThemeTransition(() => {
      el.dataset.theme = effective;
      el.dataset.themeSetting = setting;

      setThemeIcon(setting, effective);
    });
  };

  const nextSetting = (current) =>
    current === "auto" ? "light" : current === "light" ? "dark" : "auto";

  const wireThemeToggle = () => {
    const btn = root.getElementById("themeToggle");
    if (!btn) return;

    btn.addEventListener("click", () => {
      const current = getSetting();
      const next = nextSetting(current);
      setSetting(next);
      applyTheme();
    });
  };

  const wireNavbarCollapseOnClick = () => {
    const nav = root.getElementById("mainNavbar");
    if (!nav) return;

    const collapseIfOpen = () => {
      if (!nav.classList.contains("show")) return;

      if (window.bootstrap && window.bootstrap.Collapse) {
        const inst =
          window.bootstrap.Collapse.getInstance(nav) ||
          new window.bootstrap.Collapse(nav, { toggle: false });
        inst.hide();
      } else {
        nav.classList.remove("show");
      }
    };

    root.querySelectorAll('.navbar .nav-link[href^="#"]').forEach((a) => {
      a.addEventListener("click", () => {
        collapseIfOpen();
      });
    });
  };

  applyTheme();
  wireThemeToggle();
  wireNavbarCollapseOnClick();

  if (window.matchMedia) {
    const mql = window.matchMedia("(prefers-color-scheme: dark)");
    const handler = () => {
      if (getSetting() === "auto") applyTheme();
    };
    mql.addEventListener("change", handler);
  }
})(document);

const scrollHint = document.querySelector(".toru-scroll-hint");
if (scrollHint) {
  let idleTimerId = null;

  const show = () => {
    scrollHint.classList.remove("toru-scroll-hint--hidden");
  };

  const hide = () => {
    scrollHint.classList.add("toru-scroll-hint--hidden");
  };

  const scheduleShowAfterIdle = () => {
    if (idleTimerId) window.clearTimeout(idleTimerId);
    idleTimerId = window.setTimeout(() => {
      if (window.scrollY === 0) show();
    }, 3000);
  };

  const onScroll = () => {
    hide();
    scheduleShowAfterIdle();
  };

  if (window.scrollY > 0) hide();
  else show();

  window.addEventListener("scroll", onScroll, { passive: true });
}

class GayAssSlider {
  constructor(root = document) {
    this.currentSlide = 0;

    this.track = root.getElementById("sliderTrack");
    this.progress = root.getElementById("sliderProgress");
    this.prevBtn = root.getElementById("prevBtn");
    this.nextBtn = root.getElementById("nextBtn");
    this.dots = root.querySelectorAll(".toru-slider-dot");

    if (!this.track || !this.progress || !this.prevBtn || !this.nextBtn) return;

    this.totalSlides = this.dots.length || 0;
    this.autoPlayTimer = null;

    this.init();
  }

  init() {
    this.prevBtn.addEventListener("click", () => this.prevSlide());
    this.nextBtn.addEventListener("click", () => this.nextSlide());

    this.dots.forEach((dot) => {
      dot.addEventListener("click", (e) => {
        const target = e.currentTarget;
        const index = Number.parseInt(target.dataset.index, 10);
        if (Number.isNaN(index)) return;
        this.goToSlide(index);
      });
    });

    document.addEventListener("keydown", (e) => {
      if (e.key === "ArrowLeft") this.prevSlide();
      if (e.key === "ArrowRight") this.nextSlide();
    });

    this.updateSlider();
    this.startAutoPlay();
  }

  goToSlide(index) {
    if (this.totalSlides <= 0) return;

    const clamped =
      ((index % this.totalSlides) + this.totalSlides) % this.totalSlides;
    this.currentSlide = clamped;
    this.updateSlider();
    this.resetAutoPlay();
  }

  nextSlide() {
    this.goToSlide(this.currentSlide + 1);
  }

  prevSlide() {
    this.goToSlide(this.currentSlide - 1);
  }

  updateSlider() {
    const offset = -this.currentSlide * 100;
    this.track.style.transform = `translateX(${offset}%)`;

    this.dots.forEach((dot, index) => {
      dot.classList.toggle("is-active", index === this.currentSlide);
    });

    const progressPercent = ((this.currentSlide + 1) / this.totalSlides) * 100;
    this.progress.style.width = `${progressPercent}%`;
  }

  startAutoPlay() {
    if (this.totalSlides <= 1) return;

    this.autoPlayTimer = window.setInterval(() => {
      this.nextSlide();
    }, 6000);
  }

  resetAutoPlay() {
    if (this.autoPlayTimer) window.clearInterval(this.autoPlayTimer);
    this.startAutoPlay();
  }
}

function setupCenteredSectionNav(root = document) {
  const navbar = root.querySelector(".navbar.fixed-top");
  const navLinks = root.querySelectorAll('.navbar .nav-link[href^="#"]');

  const getFixedHeaderOffset = () => {
    if (!navbar) return 0;
    const rect = navbar.getBoundingClientRect();
    return Math.round(rect.height + 12);
  };

  const clamp = (n, min, max) => Math.min(max, Math.max(min, n));

  const scrollToHashCentered = (hash, behavior = "smooth") => {
    if (!hash || hash === "#") return;

    const id = hash.startsWith("#") ? hash.slice(1) : hash;
    if (!id) return;

    const el = root.getElementById(id);
    if (!el) return;

    const headerOffset = getFixedHeaderOffset();
    const rect = el.getBoundingClientRect();
    const sectionTop = window.scrollY + rect.top;
    const sectionHeight = rect.height;
    const viewportH = window.innerHeight;
    const desiredTop =
      sectionTop + (sectionHeight - viewportH) / 2 - headerOffset;

    const maxScroll =
      document.documentElement.scrollHeight - window.innerHeight;
    const top = clamp(desiredTop, 0, Math.max(0, maxScroll));

    window.scrollTo({ top, behavior });
  };

  navLinks.forEach((a) => {
    a.addEventListener("click", (e) => {
      const href = a.getAttribute("href");
      if (!href || !href.startsWith("#")) return;

      e.preventDefault();
      history.pushState(null, "", href);
      scrollToHashCentered(href, "smooth");
    });
  });

  const onInitialHash = () => {
    if (window.location.hash) {
      scrollToHashCentered(window.location.hash, "auto");
    }
  };

  window.requestAnimationFrame(() => {
    window.requestAnimationFrame(onInitialHash);
  });

  window.addEventListener("popstate", () => {
    if (window.location.hash) {
      scrollToHashCentered(window.location.hash, "smooth");
    }
  });
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => {
    new GayAssSlider(document);
    setupCenteredSectionNav(document);
  });
} else {
  new GayAssSlider(document);
  setupCenteredSectionNav(document);
}
