import { defineConfig } from "vite";

export default defineConfig({
  server: {
    port: 7777,
  },
  esbuild: {
    legalComments: "inline",
  },
});
